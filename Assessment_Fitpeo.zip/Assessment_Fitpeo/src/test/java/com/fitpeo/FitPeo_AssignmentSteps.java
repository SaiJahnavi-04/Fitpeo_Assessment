package com.fitpeo;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

public class FitPeo_AssignmentSteps {
	@Test
	public void TestFitpeo() throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		
		// Step 1 : Navigate to the FitPeo Home Page
		driver.get("https://www.fitpeo.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		// Step 2 : Navigate to the Revenue Calculator Page
		driver.findElement(By.xpath("//*[contains(text(),'Revenue Calculator')]")).click();
		//System.out.println(driver.get);
		
		// Step 3 : Scroll Down to the Slider section
		WebElement scrollIntoView = driver.findElement(By.xpath("//*[contains(text(),'Medicare Eligible Patients')]"));
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].scrollIntoView(true);", scrollIntoView);
		Thread.sleep(3000);
		
		// Step 4 : Adjust the Slider
		WebElement slider = driver.findElement(By.xpath("//*[@type='range']"));
		int value = Integer.parseInt(slider.getAttribute("aria-valuenow"));
		for(int i=1;i<=820-value;i++) {
			slider.sendKeys(Keys.ARROW_RIGHT);
		}

		// Step 5 : Update the Text Field
		String enteredValue = "560";
		WebElement enter = driver.findElement(By.xpath("//*[@type='number']"));
		int length = enter.getAttribute("value").length();
		for (int i = 0; i < length; i++) {
		    enter.sendKeys(Keys.BACK_SPACE);
		}
		enter.sendKeys(enteredValue);
		
		// Step 6 : Validate Slider Value
		WebElement sliderAt = driver.findElement(By.xpath("//*[@aria-valuenow='560']"));
		String value1 = sliderAt.getAttribute("value");
		Assert.assertEquals(enteredValue, value1);
		
		// Step 7 : Select CPT Codes
		int length1 = enter.getAttribute("value").length();
		for (int i = 0; i < length1; i++) {
		    enter.sendKeys(Keys.BACK_SPACE);
		}
		enter.sendKeys("820");
		WebElement scrollTo = driver.findElement(By.xpath("//*[contains(text(),'CPT-99091')]"));
		js.executeScript("arguments[0].scrollIntoView(true);", scrollTo);
		String[] cptCodes = {"99091", "99453", "99454", "99474"};
	    for (String code : cptCodes) {
	    	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
	        WebElement div = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[p[contains(text(),"+code+")]]"))); 
	        WebElement checkbox = div.findElement(By.cssSelector("input[type='checkbox']"));
	        checkbox.click();
	    }
	    
	    // Step 8 and Step : 9
        String headerText = driver.findElement(By.xpath("//p[@class='MuiTypography-root MuiTypography-body2 inter css-1xroguk'][4]")).getText();
        String expectedReimbursement = "$110700";
        if(headerText.contains("Total Recurring Reimbursement for all Patients Per Month:")){
        	System.out.println("Total Recurring Reimbursement for all Patients Per Month: "+expectedReimbursement);
        }
        else {
        	System.out.println("Total Recurring Reimbursement validation failed. Expected: " + expectedReimbursement + ", but found: " + headerText);
        }    
        driver.close();
	}
}